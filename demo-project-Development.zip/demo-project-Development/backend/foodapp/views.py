from rest_framework import generics, filters
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.shortcuts import render

from .models import Contact, User
from .serializers import ContactSerializer, UserSerializer


def home(request):
    return render(request, "index.html")


class ContactListCreateAPI(generics.ListCreateAPIView):

    queryset = Contact.objects.all()
    serializer_class = ContactSerializer


    filter_backends = [filters.SearchFilter]
    search_fields = ['first_name', 'last_name', 'email', 'mobile', 'comments']

    def get_permissions(self):
        if self.request.method == 'GET':
            return [AllowAny()]
        return [IsAuthenticated()]


class ContactDetailAPI(generics.RetrieveUpdateDestroyAPIView):

    queryset = Contact.objects.all()
    serializer_class = ContactSerializer
    permission_classes = [IsAuthenticated]


class UserListCreateAPI(generics.ListCreateAPIView):

    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]


class UserDetailAPI(generics.RetrieveUpdateDestroyAPIView):

    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]




"""GET /api/contacts/?search=<value>"""