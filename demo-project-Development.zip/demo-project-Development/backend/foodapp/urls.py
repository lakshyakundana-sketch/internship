from django.urls import path
from .views import (
    ContactListCreateAPI, ContactDetailAPI,
    UserListCreateAPI, UserDetailAPI
)

urlpatterns = [

    path('contacts/', ContactListCreateAPI.as_view(), name='contact-list-create'),
    path('contacts/<int:pk>/', ContactDetailAPI.as_view(), name='contact-detail'),


    path('users/', UserListCreateAPI.as_view(), name='user-list-create'),
    path('users/<int:pk>/', UserDetailAPI.as_view(), name='user-detail'),
]
